SAFA PORTFOLIO — PUBLISHING INSTRUCTIONS

This folder contains your portfolio as index.html.

To publish free with GitHub Pages:
1. Sign in to GitHub and create a new public repository, e.g. safa-portfolio.
2. Upload index.html from this folder to the repository root.
3. Open repository Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch; select main and / (root), then Save.
5. Wait for GitHub Pages to publish. Your public URL will look like:
   https://YOUR-GITHUB-USERNAME.github.io/safa-portfolio/
6. Generate a QR code using that actual URL. Do not use 127.0.0.1 or localhost.
